
local config = {}

config.motd = {}

config.motd.enabled = true -- enables or disables the MOTD
config.motd.type = "htmlOnly" -- htmlOnly: simple (large) MOTD || selectableVehicle: MOTD with the ability to select a vehicle (currently unsupported)
config.motd.title = "Welcome to O1LERs BeamMP server!" -- this is the title of the MOTD window
--MOTD body text, description, do not use tabspaces, these will affect the rendering of the description text
config.motd.description = [[
    [center][img]logo_O1LER.jpg[/img][/center]
    [br]
    [b][color=blue]Welcome to one of my BeamMP servers[/color][/b]
    All of my servers run CobaltEssentials that blocks unknown vehicles and most props from being spawned
    [br]
    [b][color=#FF0000]Rules[/color][/b]
    1. Spawn responsibly!
    2. Assume the best intentions of others!
    3. Keep the chat clean
    [br]
    Have fun! Greetings [b][color=blue]O1LER#9874[/color][/b]
    [br]
    [i][b][right]Dudekahedron#1624 [color=#FF00FF]revived this concept, inspired by [/color]Uncle Joey’s Base[/right][/b][/i]
]]
config.motd.button = "Lets gooo!" --text of the button at the bottom of the MOTD

return config
